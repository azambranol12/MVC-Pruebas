<!DOCTYPE html>
<html>
   <head>
      <title>Título de mi página web</title>
	  <link rel="stylesheet" href="style.css">
   </head>
   <body>
        <h3>Profesor</h3>
            <?php
                require_once '../Controlador/listarprofesores.php';
            ?>
        </br></br>
   </body>
</html>